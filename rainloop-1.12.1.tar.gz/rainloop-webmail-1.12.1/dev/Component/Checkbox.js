
import {componentExportHelper} from 'Component/Abstract';
import {AbstracCheckbox} from 'Component/AbstracCheckbox';

class CheckboxComponent extends AbstracCheckbox {}

export default componentExportHelper(CheckboxComponent, 'CheckboxComponent');
