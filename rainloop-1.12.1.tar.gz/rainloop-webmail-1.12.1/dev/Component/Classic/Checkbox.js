
import {componentExportHelper} from 'Component/Abstract';
import {AbstracCheckbox} from 'Component/AbstracCheckbox';

class ClassicCheckboxComponent extends AbstracCheckbox {}

export default componentExportHelper(ClassicCheckboxComponent, 'ClassicCheckboxComponent');
