
export class AbstractBoot
{
	bootstart() {/* no-empty */}
}
